class Main {
    public static void main(String[] args) {

        int a = 15;
        int b = 5;

        
        if (a > b && a > 0) {
            System.out.println("Logical AND (&&) is TRUE");
        }

        
        if (a > b || a < 0) {
            System.out.println("Logical OR (||) is TRUE");
        }

        
        if (!(a < b)) {
            System.out.println("Logical NOT (!) is TRUE");
        }
    }
}
