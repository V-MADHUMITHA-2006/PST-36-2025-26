public class Main {
    public static void main(String[] args) {

        int a = 22;
        int b = 30;

        if (a == b) {
            System.out.println("Equal");
        } else {
            System.out.println("Not Equal");
        }
    }
}
