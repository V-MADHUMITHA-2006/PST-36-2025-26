class Main {
    public static void main(String[] args) {

        int age = 16;  

        
        if (!(age >= 18)) {
            System.out.println("NOT eligible for vote");
        } else {
            System.out.println(" eligible for vote");
        }
    }
}