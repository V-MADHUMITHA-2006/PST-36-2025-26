class Main {
    public static void main(String[] args) {

        int marks = 35;   
        int grace = 2;     

        if (marks >= 40 || grace == 2) {
            System.out.println("Student has passed");
        } else {
            System.out.println("Student has failed");
        }
    }
}