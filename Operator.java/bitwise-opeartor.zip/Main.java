public class Main {
    public static void main(String[] args) {

        int a = 7;   
        int b = 2;   

        System.out.println(a & b);   
        System.out.println(a | b);  
        System.out.println(a ^ b);   
        System.out.println(~a);      
        System.out.println(a << 1);  
        System.out.println(a >> 1);  
    }
}
