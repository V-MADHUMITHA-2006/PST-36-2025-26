public class Main {
    public static void main(String[] args) {

        int left = 3;
        int right = 13;

        if (left < right) {
            System.out.println("Left value is smaller");
        } else {
            System.out.println("Left value is NOT smaller");
        }
    }
}
