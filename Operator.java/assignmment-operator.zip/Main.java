class Main {
    public static void main(String[] args) {

        int a = 15;   
        System.out.println("a = " + a);

        a += 6;      
        System.out.println("a += 5 -> " + a);

        a -= 3;       
        System.out.println("a -= 3 -> " + a);

        a *= 9;       
        System.out.println("a *= 2 -> " + a);

        a /= 4;       
        System.out.println("a /= 4 -> " + a);

        a %= 3;      
        System.out.println("a %= 3 -> " + a);
    }
}
