class Main {
    public static void main(String[] args) {

        int left = 15;
        int right = 15;

        if (left >= right) {
            System.out.println("Left value is greater than or equal to right value");
        } else {
            System.out.println("Left value is less than right value");
        }
    }
}
