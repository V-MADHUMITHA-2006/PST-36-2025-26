class Main {
    public static void main(String[] args) {

        int num = 25;  

        if (num > 10 && num < 50) {
            System.out.println(num + " is greater than 10 and less than 50");
        } else {
            System.out.println(num + " is NOT in the range 10 to 50");
        }
    }
}
