public class Main {
    public static void main(String[] args) {

        String fruits[] = {"Apple", "Orange", "Mango", "Cherry"};

        for (int i = 0; i < fruits.length; i++) {
            System.out.println(fruits[i]);
        }
    }
}
