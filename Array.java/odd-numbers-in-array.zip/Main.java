public class Main {
    public static void main(String[] args) {

        int numbers[] = {10, 21, 32, 45, 56, 77};

        for (int i = 0; i < numbers.length; i++) {

            if (numbers[i] % 2 != 0) {
                System.out.println(numbers[i]);
            }
        }
    }
}

